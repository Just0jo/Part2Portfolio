package ie.atu_ArrayList;

import java.util.Scanner;

public class ArrayDemo {
    public static void main(String[] args) {
        int[] array;
        array = new int[10];
        array[0]= 100;
        array[1]= 200;
        array[2]= 300;
        array[3]= 400;
        array[4]= 500;
        array[5]= 600;
        array[6]= 700;
        array[7]= 800;
        array[8]= 900;
        array[9]= 1000;

        System.out.println("Element at index 0:"+array[0]);
        System.out.println("Element at index 1:"+ array[1]);
        System.out.println("Element at index 2:"+ array[2]);
        System.out.println("Element at index 3:"+ array[3]);
        System.out.println("Element at index 4:"+ array[4]);
        System.out.println("Element at index 5:"+ array[5]);
        System.out.println("Element at index 6:"+ array[6]);
        System.out.println("Element at index 7:"+ array[7]);
        System.out.println("Element at index 8:"+ array[8]);

        Scanner myScan = new Scanner(System.in);
                try{
                    System.out.println("Please enter a new value" + array[10]);
                    array[10] = myScan.nextInt();

                }
                catch (IndexOutOfBoundsException e) {
                    System.out.println("Value is not within array");
                }





    }
}
