package ie.atu.productv5;

public interface Productable {
    String toString();
    String getPriceFormatted();

}
